# Projects Using Jolt

* [Artillery Eco](https://github.com/OversizedSunCoreDev/ArtilleryEco) - Plugin for Unreal Engine 5 (UE5).
* [Dagor Engine](https://github.com/GaijinEntertainment/DagorEngine) - An open source engine used by [War Thunder](https://warthunder.com/). See [here](https://github.com/GaijinEntertainment/DagorEngine/tree/main/prog/engine/phys/physJolt).
* [Death Stranding 2: On the Beach](https://www.playstation.com/en-us/games/death-stranding-2-on-the-beach/) - A third person action adventure game set in a post-apocalyptic world ravaged by otherworldly creatures.
* [ezEngine](https://github.com/ezEngine/ezEngine) - An open source C++ game engine.
* [GDevelop](https://gdevelop.io/) - An open-source, no-code game engine. See [this](https://blog.blips.fm/articles/gdevelop-55-released-with-enhanced-3d-support) announcement.
* [Godot](https://github.com/godotengine/godot) - Godot Engine – Multi-platform 2D and 3D game engine. See [this](https://godotengine.org/releases/4.4/#jolt-physics-module) announcement.
* [Horizon Forbidden West](https://www.playstation.com/en-us/games/horizon-forbidden-west/) - An open world action RPG adventure.
* [HypeHype](https://www.hypehype.com/) - A mobile app to create, remix and play games. See [this](https://twitter.com/SebAaltonen/status/1726871354228482237) X post.
* [Light Tracer Render](https://lighttracer.org/) - A rendering tool, uses Jolt for object placement. See [this](https://lighttracer.org/blog/light-tracer-render-2-4-0/) announcement.
* [LÖVR](https://lovr.org) - A Lua VR framework.  See [this](https://lovr.org/docs/v0.18.0) release announcement.
* [luxe engine](https://luxeengine.com) - A cross platform, rapid development game engine.
* [The Mirror](https://themirror.space/) - A game development platform designed to empower developers and artists with real-time, limitless creativity. See [this](https://twitter.com/themirrorgdp/status/1718019599361323023?s=20) X post.
* [Nazara Engine](https://github.com/NazaraEngine/NazaraEngine) - A cross-platform framework aimed at real-time applications (such as video games) requiring Audio, 2D/3D rendering and physics, network and more.
* [NeoAxis Engine](https://www.neoaxis.com/) - A 3D game engine. See [this](https://www.neoaxis.com/news/neoaxis_engine_2023_1_released) announcement.
* [Blood Line: A Rebel Moon Game](https://www.rebelmoongame.com/) - An online co-op action game set in the rebel moon universe.
* [Sceneri](https://www.sceneri.com/) - A mobile app for creating and sharing 3D games and experiences. See [this](https://www.sceneri.com/blog/2023-07-27-jolt-physics-bringing-sceneris-worlds-to-life) blog post.
* [Substrata](https://substrata.info/) - A metaverse platform.
* [Supernova Engine](https://www.supernovaengine.org/) - Game engine for 2D and 3D projects with entity component system (ECS) and data-oriented design.
* [Traktor Engine](https://github.com/apistol78/traktor/) - An open-source 3d game engine written in C++.
* [Unreal Jolt](https://github.com/Yadhu-S/UnrealJolt) - Plugin for Unreal Engine 5 (UE5).
* [VPhysics Jolt](https://github.com/Joshua-Ashton/VPhysics-Jolt), a replacement for Ipion Virtual Physics in the Source Engine. Can be used in e.g. [Garry's Mod](https://store.steampowered.com/app/4000/Garrys_Mod/).
* [Wicked Engine](https://wickedengine.net/) - 3D engine with modern graphics. See [X post](https://x.com/turanszkij/status/1805979390557528217) and [github](https://github.com/turanszkij/WickedEngine/blob/master/WickedEngine/wiPhysics_Jolt.cpp).
* [X4 Foundations](https://store.steampowered.com/app/392160/X4_Foundations/) - A space simulation game. See [this](https://forum.egosoft.com/viewtopic.php?t=451046) announcement.

If your project is using Jolt, open a discussion or send a PR to add it to the list.
